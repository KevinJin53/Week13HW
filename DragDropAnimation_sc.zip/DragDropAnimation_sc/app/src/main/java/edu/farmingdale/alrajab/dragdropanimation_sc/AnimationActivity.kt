package edu.farmingdale.alrajab.dragdropanimation_sc

import android.animation.ObjectAnimator
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import edu.farmingdale.alrajab.dragdropanimation_sc.databinding.ActivityAnimationBinding

class AnimationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAnimationBinding
    private var rocketImageIndex = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnimationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val startAnimationButton: Button = binding.startAnimationButton
        startAnimationButton.setOnClickListener {
            startRocketAnimation()
        }
    }

    private fun startRocketAnimation() {
        val rocketImageView: ImageView = binding.rocketImageView
        rocketImageView.setImageResource(getRocketImageResource())
        val rocketAnimator = ObjectAnimator.ofFloat(rocketImageView, "translationY", -2000f)
        rocketAnimator.duration = 5000
        rocketAnimator.addUpdateListener {
            if (rocketImageView.translationY < -500 && rocketImageIndex < 3) {
                rocketImageIndex++
                rocketImageView.setImageResource(getRocketImageResource())
            }
        }
        rocketAnimator.doOnEnd {
            rocketImageView.translationY = 0f
            rocketImageIndex = 1
            rocketImageView.setImageResource(getRocketImageResource())
        }
        rocketAnimator.start()
    }

    private fun getRocketImageResource(): Int {
        val rocketImageName = "rocket%02d".format(rocketImageIndex)
        return resources.getIdentifier(rocketImageName, "drawable", packageName)
    }
}
