package edu.farmingdale.alrajab.dragdropanimation_sc

import android.content.ClipData
import android.content.ClipDescription
import android.graphics.Canvas
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.view.DragEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import edu.farmingdale.alrajab.dragdropanimation_sc.databinding.ActivityDragAndDropViewsBinding

class DragAndDropViews : AppCompatActivity() {
    private lateinit var binding: ActivityDragAndDropViewsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDragAndDropViewsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupDragAndDropListeners()
    }

    private fun setupDragAndDropListeners() {
        val arrowDragListener = View.OnDragListener { view, dragEvent ->
            (view as? ImageView)?.let {
                when (dragEvent.action) {
                    DragEvent.ACTION_DRAG_STARTED -> {
                        highlightPlaceholder(it)
                        return@OnDragListener true
                    }
                    DragEvent.ACTION_DRAG_ENTERED -> {
                        return@OnDragListener true
                    }
                    DragEvent.ACTION_DRAG_EXITED -> {
                        return@OnDragListener true
                    }
                    DragEvent.ACTION_DROP -> {
                        val item = dragEvent.clipData.getItemAt(0)
                        val lbl = item.text.toString()
                        when (lbl) {
                            "UP" -> {
                                it.setImageResource(R.drawable.ic_baseline_arrow_upward_24)
                            }
                        }
                        return@OnDragListener true
                    }
                    DragEvent.ACTION_DRAG_ENDED -> {
                        removeHighlight(it)
                        return@OnDragListener true
                    }
                    else -> return@OnDragListener false
                }
            }
            false
        }

        binding.holder01.setOnDragListener(arrowDragListener)
        binding.holder02.setOnDragListener(arrowDragListener)

        binding.upMoveBtn.setOnLongClickListener { view: View ->
            (view as? Button)?.let {
                val item = ClipData.Item(it.tag as? CharSequence)
                val dragData = ClipData(
                    it.tag as? CharSequence,
                    arrayOf(ClipDescription.MIMETYPE_TEXT_PLAIN),
                    item
                )
                val myShadow = ArrowDragShadowBuilder(it)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    it.startDragAndDrop(dragData, myShadow, null, 0)
                } else {
                    it.startDrag(dragData, myShadow, null, 0)
                }

                true
            }
            false
        }
    }

    private fun highlightPlaceholder(imageView: ImageView) {
        imageView.setBackgroundResource(R.drawable.placeholder_highlight)
    }

    private fun removeHighlight(imageView: ImageView) {
        imageView.setBackgroundResource(0)
    }

    private class ArrowDragShadowBuilder(view: View) : View.DragShadowBuilder(view) {
        private val shadow = view.background
        override fun onProvideShadowMetrics(size: Point, touch: Point) {
            val width: Int = view.width
            val height: Int = view.height
            shadow?.setBounds(0, 0, width, height)
            size.set(width, height)
            touch.set(width / 2, height / 2)
        }

        override fun onDrawShadow(canvas: Canvas) {
            shadow?.draw(canvas)
        }
    }
}
